import React from "react";
import {
  AbsoluteFill,
  Easing,
  Img,
  interpolate,
  Series,
  useCurrentFrame,
  useVideoConfig,
  Video,
} from "remotion";
import type { VoiceSegment } from "@/lib/generate-voiceover-script";

function AdScene({
  segment,
  videoUrl,
  imageUrl,
  accentColor,
  companyName,
}: {
  segment: VoiceSegment;
  videoUrl: string | null;
  imageUrl: string | null;
  accentColor: string;
  companyName: string;
}) {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const fps = 30;

  // Scene fade in / out
  const fadeIn  = interpolate(frame, [0, 12], [0, 1], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp",
  });
  const fadeOut = interpolate(
    frame, [durationInFrames - 12, durationInFrames], [1, 0], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp",
  });
  const sceneOpacity = Math.min(fadeIn, fadeOut);

  // Ken Burns slow zoom on image fallback
  const bgScale = interpolate(frame, [0, durationInFrames], [1, 1.07], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp",
  });

  // Screen text — slides up 0.4s in, fades out near end
  const textDelay = Math.floor(fps * 0.4);
  const tf = frame - textDelay;
  const textOpacity = interpolate(
    tf,
    [0, 15, durationInFrames - 20, durationInFrames - 8],
    [0,  1,  1,                    0],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" }
  );
  const textY = interpolate(tf, [0, 15], [40, 0], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp",
    easing: Easing.out(Easing.cubic),
  });

  // Subtitle (narration text small, bottom)
  const subOpacity = interpolate(
    tf,
    [5, 20, durationInFrames - 15, durationInFrames - 5],
    [0, 0.75, 0.75, 0],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" }
  );

  // CTA bounces in at last 1.5s of closing scene
  const ctaStart   = durationInFrames - Math.floor(fps * 1.5);
  const ctaFrame   = frame - ctaStart;
  const ctaOpacity = interpolate(ctaFrame, [0, 18], [0, 1], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp",
  });
  const ctaScale = interpolate(ctaFrame, [0, 18], [0.8, 1], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp",
    easing: Easing.out(Easing.back(1.5)),
  });

  const overlayStrength =
    segment.position === "opening" ? 0.4 :
    segment.position === "closing" ? 0.6 : 0.5;

  return (
    <AbsoluteFill style={{ opacity: sceneOpacity }}>

      {/* ── BACKGROUND ── */}
      {videoUrl ? (
        <Video
          src={videoUrl}
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
          volume={0}
        />
      ) : imageUrl ? (
        <Img
          src={imageUrl}
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            transform: `scale(${bgScale})`,
            transformOrigin: "center center",
          }}
        />
      ) : (
        <div style={{
          width: "100%", height: "100%",
          background: "linear-gradient(135deg, #0f0c29, #302b63, #24243e)",
        }} />
      )}

      {/* ── DARK OVERLAY ── */}
      <AbsoluteFill
        style={{ backgroundColor: `rgba(0,0,0,${overlayStrength})` }}
      />

      {/* ── BOTTOM GRADIENT ── */}
      <div style={{
        position: "absolute",
        bottom: 0, left: 0, right: 0, height: 600,
        background: "linear-gradient(to top, rgba(0,0,0,0.92) 0%, transparent 100%)",
      }} />

      {/* ── TOP GRADIENT — opening only ── */}
      {segment.position === "opening" && (
        <div style={{
          position: "absolute",
          top: 0, left: 0, right: 0, height: 220,
          background: "linear-gradient(to bottom, rgba(0,0,0,0.55) 0%, transparent 100%)",
        }} />
      )}

      {/* ── COMPANY NAME — opening only ── */}
      {segment.position === "opening" && (
        <div style={{
          position: "absolute",
          top: 80, left: 0, right: 0,
          textAlign: "center",
          opacity: interpolate(frame, [8, 28], [0, 0.8], {
            extrapolateLeft: "clamp", extrapolateRight: "clamp",
          }),
          fontSize: 28,
          fontWeight: 600,
          color: "rgba(255,255,255,0.75)",
          fontFamily: "Arial, sans-serif",
          letterSpacing: 6,
          textTransform: "uppercase" as const,
        }}>
          {companyName}
        </div>
      )}

      {/* ── SCREEN TEXT — minimal 2-3 words ── */}
      {segment.screenText && (
        <div style={{
          position: "absolute",
          bottom: segment.showCTA ? 340 : 200,
          left: 60, right: 60,
          opacity: textOpacity,
          transform: `translateY(${textY}px)`,
          fontSize: segment.position === "opening" ? 100 : 82,
          fontWeight: 900,
          color: "#ffffff",
          textAlign: "center" as const,
          fontFamily: "Arial Black, Arial, sans-serif",
          lineHeight: 1.1,
          textShadow: "0 6px 30px rgba(0,0,0,0.8)",
        }}>
          {segment.screenText}
        </div>
      )}

      {/* ── NARRATION SUBTITLE ── */}
      <div style={{
        position: "absolute",
        bottom: segment.showCTA ? 260 : 120,
        left: 80, right: 80,
        opacity: subOpacity,
        fontSize: 28,
        fontWeight: 400,
        color: "rgba(255,255,255,0.8)",
        textAlign: "center" as const,
        fontFamily: "Arial, sans-serif",
        lineHeight: 1.45,
        textShadow: "0 2px 12px rgba(0,0,0,0.95)",
      }}>
        {segment.narration}
      </div>

      {/* ── CTA PILL — closing scene only ── */}
      {segment.showCTA && segment.ctaText && (
        <div style={{
          position: "absolute",
          bottom: 150,
          left: 0, right: 0,
          display: "flex",
          justifyContent: "center",
          opacity: ctaOpacity,
          transform: `scale(${ctaScale})`,
        }}>
          <div style={{
            backgroundColor: accentColor,
            borderRadius: 60,
            paddingLeft: 70,
            paddingRight: 70,
            paddingTop: 30,
            paddingBottom: 30,
            fontSize: 38,
            fontWeight: 900,
            color: "#ffffff",
            fontFamily: "Arial Black, Arial",
            boxShadow: `0 12px 40px rgba(0,0,0,0.5), 0 0 0 3px rgba(255,255,255,0.15)`,
            whiteSpace: "nowrap" as const,
          }}>
            {segment.ctaText}
          </div>
        </div>
      )}

      {/* ── ACCENT LINE ── */}
      <div style={{
        position: "absolute",
        bottom: 95,
        left: 80, right: 80,
        height: 2,
        backgroundColor: accentColor,
        opacity: interpolate(frame, [15, 35], [0, 0.35], {
          extrapolateLeft: "clamp", extrapolateRight: "clamp",
        }),
      }} />

    </AbsoluteFill>
  );
}

export interface MultiSceneVideoProps {
  segments:    VoiceSegment[];
  sceneVideos: (string | null)[];
  sceneImages: (string | null)[];
  accentColor: string;
  companyName: string;
}

export const MultiSceneVideo: React.FC<MultiSceneVideoProps> = ({
  segments,
  sceneVideos,
  sceneImages,
  accentColor,
  companyName,
}) => {
  return (
    <AbsoluteFill style={{ backgroundColor: "#000000" }}>
      <Series>
        {segments.map((segment, i) => (
          <Series.Sequence
            key={i}
            durationInFrames={segment.durationSeconds * 30}
          >
            <AdScene
              segment={segment}
              videoUrl={sceneVideos[i] ?? null}
              imageUrl={sceneImages[i] ?? null}
              accentColor={accentColor}
              companyName={companyName}
            />
          </Series.Sequence>
        ))}
      </Series>
    </AbsoluteFill>
  );
};