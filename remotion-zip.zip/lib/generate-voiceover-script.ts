import { google } from "@ai-sdk/google";
import { generateText } from "ai";

export interface VoiceSegment {
  narration:         string;
  screenText:        string;
  durationSeconds:   number;
  visualDescription: string;
  pexelsQuery:       string;
  position:          "opening" | "middle" | "closing";
  showCTA:           boolean;
  ctaText?:          string;
  preferWebcam?:     boolean;
  animationStyle?:   "energetic" | "calm" | "dramatic" | "warm";
  colorGrade?:       "cool" | "warm" | "high-contrast" | "muted";
  overlayStyle?:     "minimal" | "bold" | "cinematic" | "editorial";
  textPlacement?:    "bottom" | "center" | "top" | "lower-third";
  sceneEnergy?:      number; // 0.0–1.0 — drives animation speed/intensity
}

/**
 * StyleDNA — AI decides once per video.
 * Threaded through every rendering layer for visual consistency.
 * No two videos share the same DNA.
 */
export interface StyleDNA {
  primaryFont:      string;
  fontWeight:       number;
  letterSpacing:    number;
  textTransform:    "uppercase" | "none" | "capitalize";
  accentColor:      string;
  secondaryColor:   string;
  bgTint:           string;
  overlayIntensity: number;
  transitionStyle:  "cut" | "fade" | "push" | "zoom";
  textAnimStyle:    "slide-up" | "slide-left" | "zoom-in" | "typewriter";
  averageCutPace:   "fast" | "medium" | "slow";
  motionIntensity:  number;
  tone:             "inspiring" | "urgent" | "warm" | "bold" | "playful";
  narrativeArc:     "problem-solution" | "aspiration" | "story" | "comparison";
  ctaStyle:         "soft" | "hard" | "emotional";
  cinematicMood:    string;
  colorPalette:     "warm" | "cool" | "monochrome" | "vibrant" | "earthy";
  aspectRatio:      "9:16";
}

export interface VoiceoverScript {
  segments:             VoiceSegment[];
  totalDurationSeconds: number;
  companyName:          string;
  accentColor:          string;
  veo3StyleHint:        string;
  fullNarration:        string;
  styleDNA:             StyleDNA;
}

const SYSTEM_PROMPT = `You are a world-class creative director, brand strategist, and video producer.
You specialize in 45-60 second social video ads that stop scrolls and drive action.

Your process:
1. DEEPLY analyze the brand brief — product, audience, tone, competitive position
2. DECIDE a complete Style DNA — the visual/motion/narrative fingerprint unique to this brand
3. WRITE 8 segments that perfectly embody that DNA — like scenes from the same film

STYLE DNA RULES:
primaryFont — pick from this list only, match brand personality:
  "Anton" = bold, impactful, sport/urgency | "Oswald" = clean modern tech/direct
  "Playfair Display" = elegant premium luxury | "Bebas Neue" = cinematic fitness/drama
  "Merriweather" = trustworthy editorial finance/health | "Raleway" = refined minimal design
  "Cinzel" = authoritative heritage/prestige | "Archivo Black" = punchy contemporary retail
  "DM Serif Display" = editorial thoughtful media | "Montserrat" = versatile modern
  NEVER default to Oswald for luxury. NEVER use Arial/Inter/Roboto.

fontWeight: 700 (elegant) | 800 (modern) | 900 (impact)
letterSpacing: -4 to -2 (tight cinematic) | 0 (neutral) | 2-6 (airy luxury)
textTransform: "uppercase" (bold/sport) | "none" (premium editorial) | "capitalize" (warm)

accentColor: SPECIFIC memorable hex matching brand energy. Not generic blue unless perfect fit.
  Warm/energy: amber #F59E0B, coral #FF6B6B, orange #E8531A, rose #F43F5E
  Cool/tech: electric #3B82F6, cyan #06B6D4, teal #14B8A6
  Premium: gold #D4AF37, champagne #F5E6CA, burgundy #8B1A3C
  Bold: hot pink #EC4899, lime #84CC16, electric orange #FF4500

bgTint: rgba() creating consistent mood over all b-roll:
  warm dark: "rgba(20,8,3,0.5)" | cool editorial: "rgba(0,20,40,0.45)"
  amber: "rgba(40,15,0,0.42)" | neutral: "rgba(0,0,0,0.4)"

overlayIntensity: 0.25 (visual-led) → 0.65 (text-heavy)
motionIntensity: 0.3 (subtle premium) → 1.0 (maximum energy)

averageCutPace — ALL durationSeconds must match:
  "fast" = 4-5s (youth/energy/TikTok) | "medium" = 5-7s (standard) | "slow" = 7-9s (luxury/trust)

SCRIPT RULES:
- narration: natural human speech. Confident, conversational, NO corporate speak.
- screenText: 2-4 UPPERCASE WORDS. Billboard, not sentence.
- durationSeconds: MUST be within averageCutPace range.
- sceneEnergy: opening 0.7+, proof/story 0.4-0.6, final CTA always 1.0
- animationStyle & colorGrade MUST differ between consecutive segments
- preferWebcam alternates strictly: true,false,true,false,true,false,true,false

Respond ONLY with valid JSON. No markdown fences. No explanation.`;

export async function generateVoiceoverScript(
  bodyText:     string,
  companyName?: string,
  brandColor?:  string
): Promise<VoiceoverScript> {

  const userPrompt = `Analyze this brief. Decide the Style DNA. Write the script.

AD BRIEF:
"""
${bodyText}
"""

Company: ${companyName || "the company"}
Brand color hint: ${brandColor || "decide the best color for this brand"}

Return EXACTLY this JSON:
{
  "companyName": "string",
  "accentColor": "hex matching styleDNA.accentColor",
  "veo3StyleHint": "one cinematic style sentence for ALL b-roll in this video",
  "fullNarration": "all 8 narration lines as one flowing paragraph",
  "styleDNA": {
    "primaryFont": "from allowed list",
    "fontWeight": 900,
    "letterSpacing": -2,
    "textTransform": "uppercase",
    "accentColor": "hex",
    "secondaryColor": "hex",
    "bgTint": "rgba(r,g,b,a)",
    "overlayIntensity": 0.45,
    "transitionStyle": "fade",
    "textAnimStyle": "slide-up",
    "averageCutPace": "medium",
    "motionIntensity": 0.7,
    "tone": "inspiring",
    "narrativeArc": "problem-solution",
    "ctaStyle": "hard",
    "cinematicMood": "specific poetic sentence",
    "colorPalette": "warm",
    "aspectRatio": "9:16"
  },
  "segments": [
    {
      "narration": "Natural spoken words. 2-3 sentences max.",
      "screenText": "2-4 WORDS",
      "durationSeconds": 6,
      "visualDescription": "Subject + lighting + camera angle + mood + motion",
      "pexelsQuery": "3-4 word search",
      "position": "opening",
      "showCTA": false,
      "ctaText": null,
      "preferWebcam": true,
      "animationStyle": "energetic",
      "colorGrade": "high-contrast",
      "overlayStyle": "cinematic",
      "textPlacement": "lower-third",
      "sceneEnergy": 0.8
    }
  ]
}

REQUIRED 8 SEGMENTS:
1. opening,  preferWebcam:true,  showCTA:false — HOOK. First 3 words stop scrolling.
2. middle,   preferWebcam:false, showCTA:false — PROBLEM. Cinematic b-roll only.
3. middle,   preferWebcam:true,  showCTA:false — AGITATE. Real emotion.
4. middle,   preferWebcam:false, showCTA:false — SOLUTION REVEAL. B-roll.
5. middle,   preferWebcam:true,  showCTA:false — BENEFITS. High energy.
6. middle,   preferWebcam:false, showCTA:false — PROOF/STATS. Social proof b-roll.
7. middle,   preferWebcam:true,  showCTA:false — EMOTIONAL CLOSE. Direct camera.
8. closing,  preferWebcam:false, showCTA:true  — CTA. ctaText=3-5 words. sceneEnergy=1.0.`;

  try {
    const { text } = await generateText({
      model:  google("gemini-2.5-flash"),
      system: SYSTEM_PROMPT,
      prompt: userPrompt,
    });

    const clean  = text.replace(/^```(?:json)?\s*/m, "").replace(/\s*```$/m, "").trim();
    const parsed = JSON.parse(clean);
    return buildFromParsed(parsed, companyName, brandColor);

  } catch (err: any) {
    console.error("[voiceover] Gemini failed:", err.message);
    return buildFallbackScript(bodyText, companyName, brandColor);
  }
}

// ─────────────────────────────────────────────────────────────────────────
function buildFromParsed(parsed: any, companyName?: string, brandColor?: string): VoiceoverScript {
  const rawDNA: any        = parsed.styleDNA  || {};
  const rawSegments: any[] = parsed.segments  || [];

  const ALLOWED_FONTS = [
    "Impact","Georgia","Playfair Display","Bebas Neue","Montserrat","Oswald",
    "Raleway","Merriweather","Anton","Cinzel","Archivo Black","DM Serif Display",
  ];

  const styleDNA: StyleDNA = {
    primaryFont:      ALLOWED_FONTS.includes(rawDNA.primaryFont) ? rawDNA.primaryFont : "Oswald",
    fontWeight:       [700,800,900].includes(Number(rawDNA.fontWeight)) ? Number(rawDNA.fontWeight) : 900,
    letterSpacing:    clamp(Number(rawDNA.letterSpacing) || -2, -6, 10),
    textTransform:    pickStr(rawDNA.textTransform, ["uppercase","none","capitalize"], "uppercase") as any,
    accentColor:      isHex(rawDNA.accentColor) ? rawDNA.accentColor : brandColor || "#e8531a",
    secondaryColor:   isHex(rawDNA.secondaryColor) ? rawDNA.secondaryColor : "rgba(255,255,255,0.75)",
    bgTint:           typeof rawDNA.bgTint === "string" && rawDNA.bgTint.startsWith("rgba") ? rawDNA.bgTint : "rgba(0,0,0,0.45)",
    overlayIntensity: clamp(Number(rawDNA.overlayIntensity) || 0.45, 0.1, 0.7),
    transitionStyle:  pickStr(rawDNA.transitionStyle, ["cut","fade","push","zoom"],      "fade") as any,
    textAnimStyle:    pickStr(rawDNA.textAnimStyle,   ["slide-up","slide-left","zoom-in","typewriter"], "slide-up") as any,
    averageCutPace:   pickStr(rawDNA.averageCutPace,  ["fast","medium","slow"],          "medium") as any,
    motionIntensity:  clamp(Number(rawDNA.motionIntensity) || 0.7, 0.2, 1.0),
    tone:             pickStr(rawDNA.tone,  ["inspiring","urgent","warm","bold","playful"], "inspiring") as any,
    narrativeArc:     pickStr(rawDNA.narrativeArc, ["problem-solution","aspiration","story","comparison"], "problem-solution") as any,
    ctaStyle:         pickStr(rawDNA.ctaStyle, ["soft","hard","emotional"], "hard") as any,
    cinematicMood:    String(rawDNA.cinematicMood || "cinematic professional, warm natural lighting, shallow depth of field"),
    colorPalette:     pickStr(rawDNA.colorPalette, ["warm","cool","monochrome","vibrant","earthy"], "warm") as any,
    aspectRatio:      "9:16",
  };

  const [minDur, maxDur] = { fast:[4,5], medium:[5,7], slow:[7,9] }[styleDNA.averageCutPace] as [number,number];

  const A_STYLES  = ["energetic","calm","dramatic","warm"]    as const;
  const C_GRADES  = ["high-contrast","warm","cool","muted"]   as const;
  const O_STYLES  = ["minimal","bold","cinematic","editorial"] as const;
  const T_PLACES  = ["bottom","center","top","lower-third"]   as const;

  const segments: VoiceSegment[] = rawSegments.map((s: any, i: number): VoiceSegment => {
    const position: VoiceSegment["position"] =
      s.position === "opening" || s.position === "closing" ? s.position
      : i === 0 ? "opening" : i === rawSegments.length-1 ? "closing" : "middle";

    return {
      narration:         String(s.narration         || "").trim(),
      screenText:        String(s.screenText        || "").trim().toUpperCase().slice(0, 40),
      durationSeconds:   clamp(Number(s.durationSeconds) || 6, minDur, maxDur),
      visualDescription: String(s.visualDescription || "cinematic professional, warm lighting").trim(),
      pexelsQuery:       String(s.pexelsQuery        || "business professional").trim(),
      position,
      showCTA:    i === rawSegments.length-1 ? true : !!s.showCTA,
      ctaText:    s.ctaText || (position === "closing" ? "Get Started Today" : undefined),
      preferWebcam: i % 2 === 0, // enforce — AI ignores this instruction reliably
      animationStyle: pickStr(s.animationStyle, A_STYLES, A_STYLES[i % 4]) as any,
      colorGrade:     pickStr(s.colorGrade,     C_GRADES, C_GRADES[i % 4]) as any,
      overlayStyle:   pickStr(s.overlayStyle,   O_STYLES, O_STYLES[i % 4]) as any,
      textPlacement:  pickStr(s.textPlacement,  T_PLACES, T_PLACES[i % 4]) as any,
      sceneEnergy:    clamp(Number(s.sceneEnergy) || 0.6, 0, 1),
    };
  });

  // Guarantee no two consecutive scenes share animationStyle or colorGrade
  for (let i = 1; i < segments.length; i++) {
    if (segments[i].animationStyle === segments[i-1].animationStyle) {
      const pool = A_STYLES.filter(a => a !== segments[i-1].animationStyle);
      segments[i].animationStyle = pool[i % pool.length];
    }
    if (segments[i].colorGrade === segments[i-1].colorGrade) {
      const pool = C_GRADES.filter(c => c !== segments[i-1].colorGrade);
      segments[i].colorGrade = pool[i % pool.length];
    }
  }

  // Guarantee last segment is strong CTA
  if (segments.length > 0) {
    const last     = segments[segments.length-1];
    last.showCTA   = true;
    last.position  = "closing";
    last.sceneEnergy = 1.0;
    if (!last.ctaText) last.ctaText = "Get Started Today";
  }

  const fullNarration = parsed.fullNarration || segments.map(s => s.narration).join(" ");
  const totalDuration = segments.reduce((sum, s) => sum + s.durationSeconds, 0);

  console.log(`[voiceover] ✅ ${segments.length} segs ${totalDuration}s | font="${styleDNA.primaryFont}" tone="${styleDNA.tone}" pace="${styleDNA.averageCutPace}" accent="${styleDNA.accentColor}"`);

  return {
    segments, totalDurationSeconds: totalDuration,
    companyName:   parsed.companyName || companyName || "Brand",
    accentColor:   styleDNA.accentColor,
    veo3StyleHint: String(parsed.veo3StyleHint || styleDNA.cinematicMood),
    fullNarration, styleDNA,
  };
}

// ─────────────────────────────────────────────────────────────────────────
function clamp(n: number, min: number, max: number): number {
  return isNaN(n) ? min : Math.max(min, Math.min(max, n));
}
function pickStr<T extends string>(val: any, allowed: readonly T[], fallback: T): T {
  return (allowed as unknown as string[]).includes(val) ? (val as T) : fallback;
}
function isHex(v: any): boolean {
  return typeof v === "string" && /^#[0-9a-f]{6}$/i.test(v.trim());
}

// ─────────────────────────────────────────────────────────────────────────
function buildFallbackScript(bodyText: string, companyName?: string, brandColor?: string): VoiceoverScript {
  const name  = companyName || "we";
  const lines = bodyText.split("\n").map(l => l.trim()).filter(Boolean);
  const get   = (i: number, fb: string) => lines[i] || fb;

  const dna: StyleDNA = {
    primaryFont: "Oswald", fontWeight: 900, letterSpacing: -2, textTransform: "uppercase",
    accentColor: brandColor || "#e8531a", secondaryColor: "rgba(255,255,255,0.7)",
    bgTint: "rgba(15,5,0,0.48)", overlayIntensity: 0.48,
    transitionStyle: "fade", textAnimStyle: "slide-up", averageCutPace: "medium",
    motionIntensity: 0.75, tone: "inspiring", narrativeArc: "problem-solution",
    ctaStyle: "hard",
    cinematicMood: "cinematic documentary warmth, shallow depth of field, golden hour light",
    colorPalette: "warm", aspectRatio: "9:16",
  };

  const segments: VoiceSegment[] = [
    { narration: get(0,"What if running your business didn't have to feel this hard?"), screenText: "SOUND FAMILIAR?", durationSeconds: 6, visualDescription: "Tired entrepreneur at cluttered desk, single warm lamp, slow zoom out", pexelsQuery: "stressed entrepreneur night", position: "opening", showCTA: false, preferWebcam: true, animationStyle: "dramatic", colorGrade: "cool", overlayStyle: "cinematic", textPlacement: "lower-third", sceneEnergy: 0.7 },
    { narration: get(1,"Every day, businesses just like yours lose time, money, and momentum to the same problems."), screenText: "EVERY. DAY.", durationSeconds: 6, visualDescription: "Timelapse of busy office, people rushing, warm amber overhead, wide shot", pexelsQuery: "busy office timelapse", position: "middle", showCTA: false, preferWebcam: false, animationStyle: "energetic", colorGrade: "warm", overlayStyle: "bold", textPlacement: "center", sceneEnergy: 0.9 },
    { narration: get(2,"You've tried everything. And here you are, still stuck in the same cycle."), screenText: "STILL STUCK?", durationSeconds: 6, visualDescription: "Person frustrated at laptop, papers scattered, cinematic shallow focus side light", pexelsQuery: "frustrated person laptop", position: "middle", showCTA: false, preferWebcam: true, animationStyle: "calm", colorGrade: "muted", overlayStyle: "editorial", textPlacement: "lower-third", sceneEnergy: 0.4 },
    { narration: get(3,`That's exactly why ${name} was built. Something completely different from the ground up.`), screenText: "UNTIL NOW.", durationSeconds: 6, visualDescription: "Sunrise over modern glass office, golden hour crane shot pulling back", pexelsQuery: "sunrise modern office", position: "middle", showCTA: false, preferWebcam: false, animationStyle: "warm", colorGrade: "high-contrast", overlayStyle: "minimal", textPlacement: "center", sceneEnergy: 0.6 },
    { narration: get(4,"Imagine more time, more clarity, total confidence in every decision you make."), screenText: "IMAGINE THIS.", durationSeconds: 6, visualDescription: "Confident professional smiling at screen results, bright modern office, medium close-up", pexelsQuery: "confident professional success", position: "middle", showCTA: false, preferWebcam: true, animationStyle: "energetic", colorGrade: "warm", overlayStyle: "cinematic", textPlacement: "lower-third", sceneEnergy: 0.85 },
    { narration: get(5,"Thousands of businesses have already made the switch. The results speak for themselves."), screenText: "REAL RESULTS.", durationSeconds: 6, visualDescription: "Clean analytics dashboard upward trends, cool blue, minimal UI, rack focus", pexelsQuery: "business analytics dashboard", position: "middle", showCTA: false, preferWebcam: false, animationStyle: "dramatic", colorGrade: "cool", overlayStyle: "bold", textPlacement: "bottom", sceneEnergy: 0.65 },
    { narration: get(6,"I wish someone had shown me this sooner. Now I'm showing it to you."), screenText: "YOUR MOMENT.", durationSeconds: 6, visualDescription: "Person looking directly into camera, warm soft backlight, intimate close-up", pexelsQuery: "authentic person direct camera", position: "middle", showCTA: false, preferWebcam: true, animationStyle: "warm", colorGrade: "warm", overlayStyle: "editorial", textPlacement: "lower-third", sceneEnergy: 0.55 },
    { narration: `Don't wait for the perfect moment. This is it. Try ${name} today — completely free.`, screenText: "START FREE TODAY", durationSeconds: 6, visualDescription: "Dynamic brand reveal, bold product/logo, strong rim lighting, fast push-in", pexelsQuery: "brand product launch reveal", position: "closing", showCTA: true, ctaText: "Start Free Today", preferWebcam: false, animationStyle: "energetic", colorGrade: "high-contrast", overlayStyle: "bold", textPlacement: "center", sceneEnergy: 1.0 },
  ];

  return {
    segments, totalDurationSeconds: 48,
    companyName: companyName || "Brand",
    accentColor: dna.accentColor,
    veo3StyleHint: dna.cinematicMood,
    fullNarration: segments.map(s => s.narration).join(" "),
    styleDNA: dna,
  };
}