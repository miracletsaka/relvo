import type { SpeechMarker, MarkerType } from "@/remotion/compositions/SpeechMarker";

interface MarkerPattern {
  regex:   RegExp;
  type:    MarkerType;
  format?: (m: string) => string;
}

const PATTERNS: MarkerPattern[] = [
  { regex: /\$[\d,]+(?:\.\d+)?(?:K|M|B)?/gi,  type: "money",    format: m => m },
  { regex: /\d+(?:\.\d+)?%/g,                  type: "stat",     format: m => m },
  { regex: /\b\d[\d,.]*(?:[xX])?\b/g,          type: "stat",     format: m => m },
  {
    regex: /\b(FREE|NOW|TODAY|INSTANTLY|GUARANTEED|LIMITED|EXCLUSIVE|PROVEN|FASTEST|ONLY|SAVE|WIN|BEST|NEW|JUST)\b/gi,
    type:  "power", format: m => m.toUpperCase(),
  },
  {
    regex: /\b(GAME CHANGER|RIGHT NOW|NO RISK|ZERO COST|LIFE CHANGING|NUMBER ONE)\b/gi,
    type:  "emphasis", format: m => m.toUpperCase(),
  },
];

// Estimate seconds-per-word based on scene energy
// energy 0.0 = slow 2.0 wps, energy 1.0 = fast 3.2 wps
function estimateWordTimings(text: string, durationSeconds: number, sceneEnergy = 0.6): Map<number, number> {
  const words      = text.replace(/[^\w\s']/g, " ").split(/\s+/).filter(Boolean);
  const wps        = 2.0 + sceneEnergy * 1.2;
  const startDelay = 0.28;
  const timings    = new Map<number, number>();

  for (let i = 0; i < words.length; i++) {
    const t = startDelay + i / wps;
    timings.set(i, Math.min(t, durationSeconds - 0.6));
  }
  return timings;
}

export function extractSpeechMarkers(
  narration:       string,
  durationSeconds: number,
  sceneEnergy      = 0.6,
  companyName?:    string,
  maxMarkers       = 4,
): SpeechMarker[] {
  if (!narration?.trim()) return [];

  const words    = narration.replace(/[^\w\s']/g, " ").split(/\s+/).filter(Boolean);
  const timings  = estimateWordTimings(narration, durationSeconds, sceneEnergy);
  const markers: SpeechMarker[] = [];
  const seen     = new Set<string>();

  for (const { regex, type, format } of PATTERNS) {
    regex.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = regex.exec(narration)) !== null) {
      const raw      = m[0];
      const display  = format ? format(raw) : raw.toUpperCase();
      const key      = display.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);

      // Find word index by counting words before match position
      const before     = narration.slice(0, m.index).replace(/[^\w\s]/g, " ").split(/\s+/).filter(Boolean);
      const wordIdx    = Math.min(before.length, words.length - 1);
      const t          = timings.get(wordIdx) ?? before.length / 2.5;

      if (t > durationSeconds - 0.8) continue;

      markers.push({ word: display, relativeTimeSeconds: t, type });
      if (markers.length >= maxMarkers) break;
    }
    if (markers.length >= maxMarkers) break;
  }

  // Company name mention
  if (companyName && markers.length < maxMarkers) {
    const lo  = narration.toLowerCase();
    const clo = companyName.toLowerCase();
    const idx = lo.indexOf(clo);
    if (idx !== -1) {
      const key = clo;
      if (!seen.has(key)) {
        const before  = narration.slice(0, idx).replace(/[^\w\s]/g, " ").split(/\s+/).filter(Boolean);
        const wordIdx = Math.min(before.length, words.length - 1);
        const t       = timings.get(wordIdx) ?? 1.0;
        if (t < durationSeconds - 0.8) {
          seen.add(key);
          markers.push({ word: companyName.toUpperCase(), relativeTimeSeconds: t, type: "brand" });
        }
      }
    }
  }

  // Sort by time, enforce 1.2s minimum gap between markers
  markers.sort((a, b) => a.relativeTimeSeconds - b.relativeTimeSeconds);
  const filtered: SpeechMarker[] = [];
  let lastT = -999;
  for (const m of markers) {
    if (m.relativeTimeSeconds - lastT >= 1.2) {
      filtered.push(m);
      lastT = m.relativeTimeSeconds;
    }
  }

  return filtered.slice(0, maxMarkers);
}

// ─────────────────────────────────────────────────────────────────────────────
// Frame-accurate version using ElevenLabs word timestamps
// ─────────────────────────────────────────────────────────────────────────────
export interface ElevenLabsWordTiming {
  word:       string;
  start_time: number;
  end_time:   number;
}

export function extractMarkersFromTimestamps(
  narration:       string,
  wordTimings:     ElevenLabsWordTiming[],
  sceneStartTime:  number,  // seconds into the full audio where this scene starts
  durationSeconds: number,
  companyName?:    string,
  maxMarkers       = 4,
): SpeechMarker[] {
  if (!wordTimings?.length) {
    return extractSpeechMarkers(narration, durationSeconds, 0.6, companyName, maxMarkers);
  }

  const markers: SpeechMarker[] = [];
  const seen     = new Set<string>();

  for (const timing of wordTimings) {
    const relTime = timing.start_time - sceneStartTime;
    if (relTime < 0 || relTime > durationSeconds - 0.5) continue;

    const word  = timing.word.trim();
    if (word.length < 2) continue;

    let matchedType: MarkerType | null = null;
    let display = word.toUpperCase();

    for (const { regex, type, format } of PATTERNS) {
      regex.lastIndex = 0;
      if (regex.test(word)) {
        matchedType = type;
        display     = format ? format(word) : word.toUpperCase();
        break;
      }
    }

    if (!matchedType && companyName && word.toLowerCase() === companyName.toLowerCase()) {
      matchedType = "brand";
      display     = companyName.toUpperCase();
    }

    if (!matchedType) continue;

    const key = display.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);

    markers.push({ word: display, relativeTimeSeconds: relTime, type: matchedType });
    if (markers.length >= maxMarkers) break;
  }

  markers.sort((a, b) => a.relativeTimeSeconds - b.relativeTimeSeconds);
  const filtered: SpeechMarker[] = [];
  let lastT = -999;
  for (const m of markers) {
    if (m.relativeTimeSeconds - lastT >= 1.2) {
      filtered.push(m);
      lastT = m.relativeTimeSeconds;
    }
  }
  return filtered.slice(0, maxMarkers);
}