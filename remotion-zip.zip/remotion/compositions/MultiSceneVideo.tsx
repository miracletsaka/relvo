import React from "react";
import {
  AbsoluteFill, Audio, Easing, Img, interpolate,
  OffthreadVideo, Sequence, Series,
  useCurrentFrame, useVideoConfig,
} from "remotion";
import type { VoiceSegment } from "@/lib/generate-voiceover-script";
import type { StyleDNA } from "@/lib/generate-voiceover-script";
import type { TemplateShape } from "@/lib/types";
import { AnimatedTemplate } from "./AnimatedTemplate";
import { SpeechMarkerLayer, type SpeechMarker } from "./SpeechMarker";

// ── Props — must stay in sync with route.ts inputProps ───────────────────────
export interface MultiSceneVideoProps {
  segments:            VoiceSegment[];
  sceneVideos:         (string | null)[];
  sceneImages:         (string | null)[];
  sceneShapes:         TemplateShape[][];
  sceneIsWebcam:       boolean[];
  sceneDurations:      number[];
  userRecordedVoice:   boolean;
  campaignData:        Record<string, any>;
  accentColor:         string;
  companyName:         string;
  styleDNA?:           StyleDNA;
  musicUrl?:           string;
  voiceUrl?:           string;
  sceneAudioUrls:      (string | null)[];   // webcam clip audio per-scene (CASE A)
  brollAudioUrls:      (string | null)[];   // b-roll recorded audio per-scene (CASE A)
  sceneSpeechMarkers?: SpeechMarker[][];    // word-sync keyword chips
  audioPath?:          string;              // legacy fallback
}

// ── B-roll audio may be plain URL or JSON slice { url, startFrom, endAt } ────
function parseBrollAudio(raw: string): { url: string; startFrom?: number; endAt?: number } {
  if (raw.startsWith("{")) {
    try { return JSON.parse(raw); } catch {}
  }
  return { url: raw };
}

// ── Animation helpers ─────────────────────────────────────────────────────────
type AnimVariant = "slideUp" | "slideLeft" | "zoomIn" | "fadeScale";

function resolveAnimVariant(segment: VoiceSegment, styleDNA?: StyleDNA): AnimVariant {
  if (styleDNA?.textAnimStyle === "slide-left")  return "slideLeft";
  if (styleDNA?.textAnimStyle === "zoom-in")     return "zoomIn";
  if (styleDNA?.textAnimStyle === "typewriter")  return "slideUp";
  if (segment.animationStyle  === "energetic")   return "zoomIn";
  if (segment.animationStyle  === "calm")        return "fadeScale";
  if (segment.animationStyle  === "dramatic")    return "slideLeft";
  return "slideUp";
}

function useTextAnim(frame: number, dur: number, variant: AnimVariant, delay = 9, amp = 1.0) {
  const tf      = frame - delay;
  const opacity = interpolate(tf, [0, 14, dur - 14, dur - 4], [0, 1, 1, 0], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp",
  });
  let transform = "";
  if (variant === "slideUp")   transform = `translateY(${interpolate(tf,[0,14],[36*amp,0],{extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.out(Easing.cubic)})}px)`;
  if (variant === "slideLeft") transform = `translateX(${interpolate(tf,[0,14],[48*amp,0],{extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.out(Easing.cubic)})}px)`;
  if (variant === "zoomIn")    transform = `scale(${interpolate(tf,[0,14],[1-0.22*amp,1],{extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.out(Easing.back(1.3))})})`;
  if (variant === "fadeScale") transform = `scale(${interpolate(tf,[0,14],[1+0.1*amp,1],{extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.out(Easing.quad)})})`;
  return { opacity, transform };
}

// ── AdScene ───────────────────────────────────────────────────────────────────
function AdScene({
  segment, sceneIndex, videoUrl, imageUrl, shapes, campaignData,
  accentColor, companyName, isWebcam, styleDNA, speechMarkers,
}: {
  segment:       VoiceSegment;
  sceneIndex:    number;
  videoUrl:      string | null;
  imageUrl:      string | null;
  shapes:        TemplateShape[];
  campaignData:  Record<string, any>;
  accentColor:   string;
  companyName:   string;
  isWebcam:      boolean;
  styleDNA?:     StyleDNA;
  speechMarkers: SpeechMarker[];
}) {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();

  const font          = styleDNA?.primaryFont      || "Oswald";
  const fontWeight    = styleDNA?.fontWeight       || 900;
  const letterSpacing = styleDNA?.letterSpacing    ?? -2;
  const textTransform = styleDNA?.textTransform    || "uppercase";
  const bgTint        = styleDNA?.bgTint           || "rgba(0,0,0,0.45)";
  const overlayOp     = styleDNA?.overlayIntensity ?? 0.45;
  const motionAmp     = (styleDNA?.motionIntensity ?? 0.75) * (segment.sceneEnergy ?? 0.6);
  const animVariant   = resolveAnimVariant(segment, styleDNA);

  const sceneOp  = Math.min(
    interpolate(frame, [0,10], [0,1], { extrapolateLeft:"clamp", extrapolateRight:"clamp" }),
    interpolate(frame, [durationInFrames-10, durationInFrames], [1,0], { extrapolateLeft:"clamp", extrapolateRight:"clamp" })
  );
  const bgScale  = interpolate(frame, [0, durationInFrames], [1, 1+0.07*(segment.sceneEnergy??0.6)], { extrapolateLeft:"clamp", extrapolateRight:"clamp" });
  const mainAnim = useTextAnim(frame, durationInFrames, animVariant, 9,  motionAmp);
  const subAnim  = useTextAnim(frame, durationInFrames, animVariant, 18, motionAmp*0.7);
  const ctaOp    = interpolate(frame-(durationInFrames-45), [0,18], [0,1], { extrapolateLeft:"clamp", extrapolateRight:"clamp" });
  const ctaScale = interpolate(frame-(durationInFrames-45), [0,18], [0.8,1], { extrapolateLeft:"clamp", extrapolateRight:"clamp", easing:Easing.out(Easing.back(1.5)) });
  const barP     = interpolate(frame, [9,28], [0,1], { extrapolateLeft:"clamp", extrapolateRight:"clamp" });
  const ltOp     = interpolate(frame, [9,24], [0,1], { extrapolateLeft:"clamp", extrapolateRight:"clamp" });
  const ltY      = interpolate(frame, [9,24], [56*motionAmp, 0], { extrapolateLeft:"clamp", extrapolateRight:"clamp", easing:Easing.out(Easing.cubic) });
  const brandOp  = interpolate(frame, [6,22], [0,0.92], { extrapolateLeft:"clamp", extrapolateRight:"clamp" });

  const textStyle: React.CSSProperties = {
    fontFamily:    `"${font}", Impact, "Arial Black", sans-serif`,
    fontWeight,
    letterSpacing: `${letterSpacing}px`,
    textTransform: textTransform as any,
  };

  return (
    <AbsoluteFill style={{ opacity: sceneOp }}>
      {/* Background — OffthreadVideo for reliable per-frame extraction */}
      {videoUrl ? (
        <OffthreadVideo src={videoUrl} style={{ width:"100%", height:"100%", objectFit:"cover" }} volume={0} />
      ) : imageUrl ? (
        <Img src={imageUrl} style={{ width:"100%", height:"100%", objectFit:"cover", transform:`scale(${bgScale})` }} />
      ) : (
        <div style={{ width:"100%", height:"100%", background:"linear-gradient(135deg,#0f0c29 0%,#302b63 50%,#24243e 100%)" }} />
      )}

      {/* Consistent atmospheric tint from StyleDNA */}
      <AbsoluteFill style={{ backgroundColor: bgTint, opacity: overlayOp }} />

      {isWebcam ? (
        <>
          <div style={{ position:"absolute", inset:0, background:"radial-gradient(ellipse at center,transparent 45%,rgba(0,0,0,.42) 100%)", pointerEvents:"none" }} />
          <div style={{ position:"absolute", bottom:0, left:0, right:0, height:340, background:"linear-gradient(to top,rgba(0,0,0,.85) 0%,transparent 100%)" }} />
          {/* Brand badge */}
          <div style={{ position:"absolute", top:52, left:52, opacity:brandOp, display:"flex", alignItems:"center", gap:10 }}>
            <div style={{ width:10, height:10, borderRadius:"50%", backgroundColor:accentColor, boxShadow:`0 0 10px ${accentColor}` }} />
            <span style={{ ...textStyle, fontSize:20, color:"rgba(255,255,255,.92)", letterSpacing:"4px" }}>
              {companyName.toUpperCase()}
            </span>
          </div>
          {/* Lower-third */}
          <div style={{ position:"absolute", bottom:72, left:0, right:0, opacity:ltOp, transform:`translateY(${ltY}px)` }}>
            <div style={{ position:"absolute", left:50, bottom:10, width:4, height:`${barP*58}px`, backgroundColor:accentColor, borderRadius:2, transformOrigin:"bottom center" }} />
            <div style={{ marginLeft:68, marginRight:52, ...textStyle, fontSize:42, color:"#fff", lineHeight:1.12, textShadow:"0 2px 16px rgba(0,0,0,.85)" }}>
              {segment.screenText}
            </div>
            <div style={{ marginLeft:68, marginRight:52, marginTop:8, fontSize:21, color:"rgba(255,255,255,.78)", fontFamily:`"${font}", sans-serif`, lineHeight:1.45, textShadow:"0 1px 10px rgba(0,0,0,.95)", fontWeight:400, textTransform:"none" }}>
              {segment.narration}
            </div>
          </div>
          {segment.showCTA && segment.ctaText && (
            <div style={{ position:"absolute", bottom:210, left:0, right:0, display:"flex", justifyContent:"center", opacity:ctaOp, transform:`scale(${ctaScale})`, zIndex:100 }}>
              <div style={{ backgroundColor:accentColor, borderRadius:60, padding:"26px 60px", ...textStyle, fontSize:36, color:"#fff", boxShadow:`0 12px 40px rgba(0,0,0,.5),0 0 60px ${accentColor}40`, whiteSpace:"nowrap" as const }}>
                {segment.ctaText}
              </div>
            </div>
          )}
        </>
      ) : (
        <>
          <AbsoluteFill style={{ backgroundColor:`rgba(0,0,0,${segment.position==="opening"?0.22:segment.position==="closing"?0.48:0.35})` }} />
          <div style={{ position:"absolute", bottom:0, left:0, right:0, height:520, background:"linear-gradient(to top,rgba(0,0,0,.88) 0%,transparent 100%)" }} />
          {shapes.length > 0 && (
            <AnimatedTemplate
              shapes={shapes}
              campaignData={campaignData}
              styleDNA={styleDNA}
              templateOpacity={interpolate(frame,[8,26],[0,0.9],{extrapolateLeft:"clamp",extrapolateRight:"clamp"})}
            />
          )}
          <div style={{ position:"absolute", bottom:segment.showCTA?400:270, left:60, width:`${barP*110}px`, height:4, backgroundColor:accentColor, borderRadius:2, boxShadow:`0 0 20px ${accentColor}60` }} />
          {segment.screenText && (
            <div style={{ position:"absolute", bottom:segment.showCTA?340:190, left:60, right:60, ...mainAnim, ...textStyle, fontSize:segment.position==="opening"?92:74, color:"#fff", textAlign:"center" as const, lineHeight:1.1, textShadow:"0 6px 32px rgba(0,0,0,.92)" }}>
              {segment.screenText}
            </div>
          )}
          <div style={{ position:"absolute", bottom:segment.showCTA?258:98, left:80, right:80, ...subAnim, fontSize:26, color:"rgba(255,255,255,.85)", textAlign:"center" as const, fontFamily:`"${font}", sans-serif`, fontWeight:400, textTransform:"none" as any, lineHeight:1.48, textShadow:"0 2px 14px rgba(0,0,0,.95)" }}>
            {segment.narration}
          </div>
          {segment.showCTA && segment.ctaText && (
            <div style={{ position:"absolute", bottom:140, left:0, right:0, display:"flex", justifyContent:"center", opacity:ctaOp, transform:`scale(${ctaScale})`, zIndex:100 }}>
              <div style={{ backgroundColor:accentColor, borderRadius:60, padding:"30px 70px", ...textStyle, fontSize:38, color:"#fff", boxShadow:`0 12px 40px rgba(0,0,0,.5),0 0 80px ${accentColor}50`, whiteSpace:"nowrap" as const }}>
                {segment.ctaText}
              </div>
            </div>
          )}
        </>
      )}

      {/* Speech marker keyword chips — on top of every scene */}
      <SpeechMarkerLayer
        markers={speechMarkers}
        styleDNA={styleDNA}
        accentColor={accentColor}
      />
    </AbsoluteFill>
  );
}

// ── Root composition ──────────────────────────────────────────────────────────
export const MultiSceneVideo: React.FC<MultiSceneVideoProps> = ({
  segments, sceneVideos, sceneImages, sceneShapes,
  sceneIsWebcam, sceneDurations, userRecordedVoice,
  campaignData, accentColor, companyName,
  styleDNA, musicUrl, voiceUrl,
  sceneAudioUrls, brollAudioUrls,
  sceneSpeechMarkers, audioPath,
}) => {
  const fps = 30;

  // Cumulative start frames — used for <Sequence from> positioning
  const sceneStartFrames: number[] = [];
  let acc = 0;
  for (const d of (sceneDurations ?? [])) {
    sceneStartFrames.push(acc);
    acc += Math.round(d * fps);
  }

  return (
    <AbsoluteFill style={{ backgroundColor: "#000" }}>

      {/* ── Music: 12% volume, full video duration ─────────────────────── */}
      {musicUrl && <Audio src={musicUrl} volume={0.12} />}

      {/* ── CASE B: AI voice — one continuous track from frame 0 ────────── */}
      {!userRecordedVoice && voiceUrl && (
        <Audio src={voiceUrl} volume={1} />
      )}

      {/*
        ── CASE A: User voice ────────────────────────────────────────────────
        sceneAudioUrls[i] = webcam recording audio → positioned at scene start
        brollAudioUrls[i] = b-roll recording audio → positioned at scene start
                            (may be plain URL or JSON { url, startFrom, endAt })

        KEY FIX: <Sequence from={startFrame}> places each clip at the correct
        absolute frame position. This eliminates silence gaps between scenes
        because each clip starts EXACTLY when its scene begins — not at frame 0.
      */}

      {userRecordedVoice && (sceneAudioUrls ?? []).map((audioUrl, i) => {
        if (!audioUrl) return null;
        const startFrame     = sceneStartFrames[i] ?? 0;
        const durationFrames = Math.round((sceneDurations?.[i] ?? 6) * fps);
        return (
          <Sequence key={`wc-audio-${i}`} from={startFrame} durationInFrames={durationFrames}>
            <Audio src={audioUrl} volume={1} />
          </Sequence>
        );
      })}

      {userRecordedVoice && (brollAudioUrls ?? []).map((raw, i) => {
        if (!raw) return null;
        const startFrame     = sceneStartFrames[i] ?? 0;
        const durationFrames = Math.round((sceneDurations?.[i] ?? 6) * fps);
        const { url, startFrom, endAt } = parseBrollAudio(raw);
        return (
          <Sequence key={`broll-audio-${i}`} from={startFrame} durationInFrames={durationFrames}>
            <Audio
              src={url}
              volume={1}
              startFrom={startFrom}
              endAt={endAt}
            />
          </Sequence>
        );
      })}

      {/* Legacy audioPath fallback */}
      {!musicUrl && !voiceUrl && audioPath && <Audio src={audioPath} volume={1} />}

      {/* ── Video scenes ──────────────────────────────────────────────────── */}
      <Series>
        {segments.map((segment, i) => {
          const dSecs   = sceneDurations?.[i] ?? segment.durationSeconds;
          const dFrames = Math.max(1, Math.round(dSecs * fps));
          return (
            <Series.Sequence key={i} durationInFrames={dFrames}>
              <AdScene
                segment={segment}
                sceneIndex={i}
                videoUrl={sceneVideos[i] ?? null}
                imageUrl={sceneImages[i] ?? null}
                shapes={sceneShapes[i] ?? []}
                campaignData={campaignData}
                accentColor={accentColor}
                companyName={companyName}
                isWebcam={sceneIsWebcam[i] ?? false}
                styleDNA={styleDNA}
                speechMarkers={sceneSpeechMarkers?.[i] ?? []}
              />
            </Series.Sequence>
          );
        })}
      </Series>
    </AbsoluteFill>
  );
};